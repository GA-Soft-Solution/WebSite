import PropTypes from "prop-types";
import { Sidebar } from "../components/Sidebar";
import { useNewsData } from "../hooks/useNewsData";
import { useRef, useState, useEffect } from "react";
import ArticleContent from "./ArticleContent"; 

const ArticleDetail = ({ articleId }) => {
  const {
    getNewsItemById,
    categories = [],
    tags = [],
    popularPosts = [],
  } = useNewsData();
  const article = getNewsItemById(articleId);

  const excerptRef = useRef(null);
  const [progress, setProgress] = useState(0);

  // Scroll progress handler
  useEffect(() => {
    const handleScroll = () => {
      if (!excerptRef.current) return;
      const rect = excerptRef.current.getBoundingClientRect();
      const windowHeight = window.innerHeight;

      const totalHeight = rect.height;
      const distance = windowHeight - rect.top;
      const scrolled = Math.min(Math.max(distance, 0), totalHeight);

      setProgress((scrolled / totalHeight) * 100);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Handle missing article
  if (!article) {
    return (
      <div className="mx-auto px-4 py-8 text-center text-red-600 font-semibold">
        Article not found
      </div>
    );
  }

  const sidebarData = { categories, tags, popularPosts };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-4 lg:mx-2">
      {/* Main Content */}
      <div className="lg:col-span-2 lg:mr-20 px-6">
        <ArticleContent
          article={article}
          excerptRef={excerptRef}
          progress={progress}
        />
      </div>

      {/* Sidebar */}
      <aside className="lg:col-span-1 lg:ml-10">
        <Sidebar {...sidebarData} />
      </aside>
    </div>
  );
};

ArticleDetail.propTypes = {
  articleId: PropTypes.string.isRequired,
};

export default ArticleDetail;
