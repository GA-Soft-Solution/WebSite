import { useState, useMemo } from 'react';
import PropTypes from 'prop-types';
import { Search } from 'lucide-react';

export const Sidebar = ({ categories, tags, popularPosts }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredPosts = useMemo(() => {
    if (!searchTerm) return popularPosts;
    return popularPosts.filter(post =>
      post.title.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm, popularPosts]);

  return (
    <div className="space-y-8">
      <div className="relative mb-4 bg-white shadow-md p-4">
        <div className="relative">
          <input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-3 pr-12 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <div className="absolute right-0 top-0 -translate-y-0 w-8 h-10 flex items-center justify-center bg-blue-500">
            <Search className="w-4 h-4 text-white" />
          </div>
        </div>
      </div>
      {/* Popular Posts */}
      <div className="bg-white p-6">
        <div className="mb-8 relative">
          <h3 className="text-lg font-bold">Popular Posts</h3>
          <div className="absolute bottom-[-0.5rem] left-0 w-full border-b border-gray-300"></div>
          <div className="absolute bottom-[-0.5rem] left-0 w-10 border-b-2 border-blue-600 pb-2"></div> 
        </div>
        <div className="space-y-4">
          {filteredPosts.length > 0 ? (
            filteredPosts.map((post, index) => (
              <div key={index} className="flex space-x-3 group">
                <img
                  src={post.image}
                  alt={post.title}
                  className="h-20 w-20"
                />
                <div className="flex-1">
                  <div className="flex items-center text-xs text-gray-500 mb-1">
                    <span className="leading-relaxed mb-2">{post.date}</span>
                  </div>
                  <h4 className="text-sm font-semibold text-gray-900 line-clamp-2 transition-colors leading-snug">
                    {post.title}
                  </h4>
                </div>
              </div>
            ))
          ) : (
            <p className="text-gray-500 text-sm">No posts found</p>
          )}
        </div>
      </div>
      {/* Categories */}
      <div className="p-6">
        <div className="mb-8 relative">
          <h3 className="text-lg font-bold text-gray-900">Categories</h3>
          <div className="absolute bottom-[-0.5rem] left-0 w-full border-b border-gray-300"></div> 
          <div className="absolute bottom-[-0.5rem] left-0 w-10 border-b-2 border-blue-600 pb-2"></div> 
        </div>
        <div className="space-y-3">
          {categories.map((category, index) => (
            <div key={index} className="flex items-center justify-between">
              <div className="flex items-center mb-2">
                <span className="w-2 h-2 bg-blue-600 rounded-sm"></span>
                <span className="ml-1 text-xs font-semibold text-gray-800">{category.name}</span>
              </div>
              <span className="text-xs">({category.count})</span>
            </div>
          ))}
        </div>
      </div>
      {/* Tags */}
      <div className="p-6">
        <div className="flex items-center mb-8 relative">
          <h3 className="text-lg font-bold text-gray-900">Tags</h3>
          <div className="absolute bottom-[-0.5rem] left-0 w-full border-b border-gray-300"></div> 
          <div className="absolute bottom-[-0.5rem] left-0 w-10 border-b-2 border-blue-600 pb-2"></div>
        </div>
        <div className="flex flex-wrap gap-2">
          {tags.map((tag, index) => (
            <span
              key={index}
              className="px-3 py-1 text-gray-700 h-10 text-sm cursor-pointer transition-colors border border-dashed border-gray-200 rounded"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

Sidebar.propTypes = {
  categories: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string.isRequired,
      count: PropTypes.number.isRequired,
    })
  ).isRequired,
  tags: PropTypes.arrayOf(PropTypes.string).isRequired,
  popularPosts: PropTypes.arrayOf(
    PropTypes.shape({
      title: PropTypes.string.isRequired,
      date: PropTypes.string.isRequired,
      image: PropTypes.string.isRequired,
    })
  ).isRequired,
};
