import { useState, useEffect } from 'react';

export const useNewsData = () => {
  const [newsItems, setNewsItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [tags, setTags] = useState([]);
  const [popularPosts, setPopularPosts] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        // Load all data files
        const [newsResponse, categoriesResponse, tagsResponse, popularResponse] = await Promise.all([
          import('../data/news.json'),
          import('../data/categories.json'),
          import('../data/tags.json'),
          import('../data/popularPosts.json')
        ]);

        setNewsItems(newsResponse.default);
        setCategories(categoriesResponse.default);
        setTags(tagsResponse.default);
        setPopularPosts(popularResponse.default);
        
        setError(null);
      } catch (err) {
        setError('Failed to load data');
        console.error('Error loading data:', err);
      }
    };

    loadData();
  }, []);

  const getNewsItemById = (id) => {
    return newsItems.find(item => item.id === id);
  };

  return {
    newsItems,
    categories,
    tags,
    popularPosts,
    error,
    getNewsItemById
  };
};